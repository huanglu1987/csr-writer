# CSR Writer — M1 至 M21（v1.1.0）

本目录实现从骨架、数值溯源、受控起草到统一合卷的 M1–M21 工作流：

- **M1**：读取已核验的 ICH E3 YAML，套用可替换母版，生成只有标题和 Word 域的 DOCX 骨架。
- **M2**：SAS ODS RTF / TFL DOCX 的物理表抽取 → 经审核的语义映射 → `datapack.json` → 占位符确定性填充 → A/B/C 三道数值守卫；支持 shell 映射前置冻结。
- **M3**：冻结五维 `study_facts`；OOXML 深度抽取；隔离起草 §11.4 与 §11.A；数值与语义红线护栏在发布前生效。
- **M4.1 模块扩展**：`study_facts → capability flags → modules` 由 23 个扩展到 41 个，覆盖给药途径/局部安全、AE 后果分层、随机化/盲法/对照、临床药理与特殊人群，以及两个治疗领域端点示例。
- **M4**：任意数量组别语义校验；方案→SAP→TFL→CSR 双向追溯；已确认正文派生 Synopsis；未引用 TFL 反向溯源；annotated/clean 双输出与人工审阅门禁；QC 结论权限护栏。
- **M5**：表/图/清单交叉引用占位符与 Word REF 域；真实 DOCX shell 的置信度提议、批量确认和版本冻结；DOCX shell→RTF 结果跨格式套值；扩展分节写手；Codex `AGENTS.md` 入口及平台文档零运行时依赖回归。
- **M6**：可配置版式引用解析；统计网格继承与数据驱动行延后解析；未引用 TFL 按预期 CSR 章节分流；13 个受控写手入口和完整 annotated 项目骨架；模型提示装配与守卫失败限次重试接口。
- **M7**：以“行能否语义化”取代标题词匹配判定占位行；数据驱动行在结果 TFL 阶段按父级路径建键；提供 `--emit-envelope` / `--ingest-draft` 零密钥 Agent 写手接口，并完成两节真实 Agent 起草、守卫重试、resolve 和 annotated 装配。
- **M8**：把 63 个技术待确认实体重组为审阅者实际判断的 15 个决策组；每组展示代表完整结构、组内差异、默认决定与影响面，并提供哈希绑定审计记录、跨 shell 版本复用/失效、决策模板和延后行结果阶段契约。
- **M9**：将路由计划接入 DOCX 渲染，以“激活模块贡献 ∪ 无条件核心节”裁剪骨架；条件节默认删除或显式保留为不适用，并留存事实依据。字母后缀节改为正式编号，局部耐受性独立设节，表号采用独立发表编号，并补齐第 3 章目录和 16.0 附录提交状态清单。
- **M10**：固定编号断层改为正文可见的方案语言声明；结论节强制同级末位；PK 展开为 11.5.1–11.5.10，并由 PK 模块动态改写 14.2 类别；全部 16.x 改由完整状态清单管理。官方 ICH 标题树恢复并以独立覆盖层本地化；新增“方案文本命中但 facts 为 false/空”的保守反向扫描，永不自动填写 facts。
- **M11**：把 16.0 的 24 条状态数据和删节声明实际渲染进 DOCX；将剂量递增固定为 12.6、安全性结论固定为 12.7；把分析集迁至 facts 驱动的 10.3，展开 9.5.x 终点和 12.x 安全性专项；完成全骨架写作分层调查及四节 Agent 起草试水。
- **M12–M15**：深化完整档 playbook，修复内部流程语言和 AI 式文风，完成句式驱动的条件化结论，并以真实结构脱敏 TFL 首次覆盖完整结果链路。
- **M16–M17**：逐单元冻结产出方式，加入建议型独立审核，落地确定性生成器、模板槽位及中文事实卡正向覆盖守卫。
- **M18–M19**：将 SAE 逐字预审与方法学有限自由生成分流，以留出集和对抗器量化安全性及误伤率，并补齐运行时接线。
- **M20**：用结构陌生的单臂开放研究完成首次真实端到端，保留并公开断点。
- **M21**：新增统一编排器和映射漂移裁决；以同一组成计划产出 clean/annotated 双版本，保留编号断层、Word 域和页码，并完成两种研究形状的零阻断端到端复验。
- **v1.1.0 维护层**：在不改动起草、守卫和编排判定的前提下，可选调用 LibreOffice 渲染和 PyMuPDF/Pillow 进行视觉前置筛查，同时生成带 A/B 类标记的缩略图墙。

边界仍然严格：确定性 section-writer 已覆盖 §9.4.3、§9.4.6、§10.1、§11.2、§11.4/§11.6、§11.5（含 §11.5.4）、§12.6、§12.1、§12.2/§12.5.1/§12.5 及少量路由激活示例，但多数仅达到结构/占位符骨架，不代表医学终稿能力。`M-BE` 只有激活槽、没有 playbook 或统计内容。本工具不编写 SAE 叙述医学内容，不自主判定因果关系或最终获益-风险，不推断缺失资料，也不给出申报/递交就绪结论。

## 环境与安装

```bash
cd "/Users/huanglu/临床试验总结报告撰写/csr-writer"
python3 -m pip install -e .
```

核心依赖为 `python-docx`、`lxml`、`PyYAML`。RTF 解析不调用 pandoc 或 LibreOffice；既有 OOXML 质检仍为纯 Python 路径。v1.1.0 视觉前置筛查可选使用 LibreOffice、PyMuPDF（`fitz`）和 Pillow；任一组件缺失时记录“未执行”并正常结束，不改变既有发布判定。

## v1.1.0 视觉前置筛查

LibreOffice 渲染目录必须位于项目目录下，不得使用 `/tmp`、`/private/tmp` 或 `/var/folders`。

```bash
python3 -m csr_writer visual-qc \
  --docx "examples/output/m21/m20_unfamiliar/07_unified_composition/M21_M20_unfamiliar.clean.docx" \
  --work-dir "examples/output/v1.1.0/visual_qc/example" \
  --json-report "examples/output/v1.1.0/visual_qc/example/report.json" \
  --markdown-report "examples/output/v1.1.0/visual_qc/example/report.md"
```

A 类为客观视觉预检阻断；B 类在 v1.1.0 全部仅警告。本检查基于 LibreOffice 渲染，与 Microsoft Word 的分页和字体回退存在差异。本检查是前置筛查，不替代在 Word 中更新域后的人工视觉复核。

## 一键复核

```bash
cd "/Users/huanglu/临床试验总结报告撰写/csr-writer"
tests/run_m1_m2_e2e.sh
tests/run_m3_e2e.sh
python3 tests/build_module_expansion_evidence.py
python3 tests/run_real_material_driven_e2e.py
python3 tests/run_m5_e2e.py --real-dir "<外部只读材料目录>"
python3 tests/run_m6_e2e.py --real-dir "<外部只读材料目录>"
python3 tests/run_m7_e2e.py --real-dir "<外部只读材料目录>"
python3 tests/run_m8_e2e.py --real-dir "<外部只读材料目录>"
python3 tests/run_m9_e2e.py --real-dir "<外部只读材料目录>"
python3 tests/run_m10_e2e.py --real-dir "<外部只读材料目录>"
python3 tests/run_m11_e2e.py --real-dir "<外部只读材料目录>"
python3 -m unittest discover -s tests -p 'test_*.py'
```

M1+M2 脚本会在 `/private/tmp` 新建隔离目录并重建母版、119 标题官方骨架、固定 21 项 OOXML QC、两份 fixture 的 datapack、解析结果和占位符结果。M3 脚本重建约数对抗报告、事实卡、路由证据、DOCX 抽取结果和两节草稿。模块扩展脚本使用脱敏等价 fixture 重建历史 41 模块清单及外用制剂对比；M11 的受控安全性专项扩展后，当前路由清单为 47 个模块。M5 及后续脚本只按批准 SHA-256 在外部目录原位读取真实材料，输出结构、哈希和脱敏合成结果，不输出真实标题、正文或路径。所有数值 demo 均为脱敏/合成结构。

## M1：标题骨架

默认只选 `ich-official`，避免把 14.1.1–14.1.3 行业惯例误标成 ICH 官方要求。

```bash
python3 -m csr_writer render-skeleton \
  --output examples/output/CSR_ICH_E3_骨架示例.docx \
  --manifest-output examples/output/skeleton_manifest.json

python3 -m csr_writer qc-format \
  --docx examples/output/CSR_ICH_E3_骨架示例.docx \
  --report examples/output/qc_format_report.json
```

需要同时展示行业惯例层时，显式指定：

```bash
python3 -m csr_writer render-skeleton \
  --layers ich-official,industry-convention \
  --output /private/tmp/CSR_ICH_E3_含行业惯例.docx
```

母版在 `skills/csr-writer/assets/csr-template-zh.docx`。渲染器只引用样式，不逐 run 写字体；替换为具有相同 style ID 契约的母版即可换风格。渲染时会清除母版遗留的横向、首页不同、奇偶页不同及旧 story，再按 `format-spec.yaml` 重建两个分节。默认母版可复建：

```bash
python3 -m csr_writer create-template \
  --output /private/tmp/csr-template-zh.docx
```

21 项 QC 同时检查 authoring profile 精确值和官方下限，包括两个分节、单栏/页面对齐、页边距/页眉页脚距离、Heading 1–5 的直接样式契约、字体字号、首行缩进、多级编号 `lvlText`、标题与 story 的 run 子结构、未锁定域的 begin/instruction/separate/end 序列、story 引用和全 story 占位符残留。DOCX 已设置 `updateFields=true`，但正式人工验收仍应在 Word 中全选并按 F9，确认目录、链接与页码更新正确。

## M2：数值管线

```bash
python3 -m csr_writer build-datapack \
  --manifest examples/demo_tfl_manifest.yaml \
  --output examples/output/datapack.json \
  --parsed-output examples/output/parsed_tables.json

python3 -m csr_writer resolve \
  --draft examples/demo_draft.md \
  --datapack examples/output/datapack.json \
  --protocol-facts examples/demo_protocol_facts.json \
  --output examples/output/resolved.txt \
  --report examples/output/guard_report.json
```

### 守卫顺序与退出码

1. **A 键存在性/语法**：任一占位符不存在或花括号异常，立即停止；B/C 标记为 `not_run`。
2. **确定性填充**：只复制 datapack 中的字符串值。
3. **B 残留检测**：任何残留 `{{...}}` 或保留缺失标记都会停止。
4. **C 裸数字检测**：在原始草稿上移除占位符后检查；项目数字只允许来自方案事实编译的精确白名单。

结果取值 `{{语义键}}` 与交叉引用 `{{@ref:T14.2.1}}` 是两类独立 token。交叉引用不参加“每个已审绑定用且仅用一次”计数；A 守卫要求实体存在于本节 `binding_manifest` 或冻结 `tfl_map`，C 守卫只放行这一种 token。正文写死“表 14.2.1”仍作为裸数字拦截。装配时 token 转为 Word `REF ... \h` 域，并为表 `T`、图 `F`、清单 `L` 创建唯一书签；中文 `表/图/清单` 前缀只在映射层转为 ASCII 键。

CLI 退出码：`0` 全部通过；`1` OOXML QC 失败；`2` 守卫 C 需人工裁决；`3` 守卫 A/B 阻断；`4` 输入、配置、解析、语义映射或 schema 错误。写入前会拒绝输入/输出、输出/输出、软链接和硬链接碰撞。如发布路径已有旧文件，先原子移至同目录 `.<文件名>.previous[.N]`；备份名会预先避开所有输入、显式输出和其他备份。datapack/parsed 与 resolved/report 均先全部 staging 再统一发布，任一写入失败都回滚，不留“部分成功”的 live 产物。守卫失败时发布路径保持不存在，旧版仍可从备份恢复，报告记录备份路径。

### 当前 TFL adapter 的明确边界

RTF 路径使用 `sas-ods-rtf-physical-v2`，支持 `clmgf/clmrg/clvmgf/clvmrg`；DOCX 路径直接读取 OOXML `gridSpan/vMerge`。两者归一到同一个物理表模型，保留合并来源、跨列表头和行缩进。多层 spanner 必须经精确人工映射后才能得到语义列；歧义 continuation、孤立 merge、未知代码页、RTF Unicode 控制、串接多个 RTF 文档或映射漂移均硬失败。当前 RTF adapter 仍限定单 RTF 文档/单物理表；单流内无可靠边界的多表不在保证范围。

语义键仍以前三维 `POP/ROW/COL` 开头，之后可附加按名称排序的键值维度，例如 `STAGE=D1/D28`。实体号支持表 `T`、图 `F` 和清单 `L`；`ROW` 可使用 `SOC/PT` 父子路径。分析集不预设枚举或大小写，`mFAS` 与英文全称均可。日期、文字判定、复合格式和状态具有独立 cell type。逐受试者宽表默认 `metadata_only`：保留表级来源、标题、分析集与理由，不建立受试者级 cell key。

`examples/demo_tfl_manifest.yaml` 是经审核的映射契约。物理表头、行标签、类型或 override 变化后必须人工更新映射；配置未使用或出现未审核标签都会阻断。`datapack.json` 记录映射 manifest 的文件名与字节 SHA-256，同时记录每份 RTF 源哈希；resolve 报告另记录 draft/datapack/protocol facts 三份实际输入文件的 SHA-256。程序不会用 `_2` 后缀掩盖冲突。

### TFL shell 前置映射

`tfl-map-candidate` 从数据锁库前的 shell datapack 和显式“实体号→ICH E3 章节”配置生成不含单元格值的候选；`tfl-map-freeze` 只有在人工确认记录与候选 SHA-256 精确绑定后才冻结；`tfl-map-apply` 在结果 TFL 到位后只允许值变化。实体、语义键、cell type、行列标签/位置、spanner 后语义列、分析集、阶段维度或章节结构漂移均以 `E-TFL-MAP-DRIFT` 阻断并输出差异。编号体系是显式配置，既可使用 ICH 14.x，也可使用供应商 1.x，不从数字前缀猜测章节。

M5 为真实 DOCX shell 增加人机工效层：

```bash
python3 -m csr_writer tfl-shell-propose \
  --docx "<只读 shell.docx>" \
  --expected-sha256 "<批准哈希>" \
  --report /private/tmp/shell_proposal.json \
  --shell-datapack-output /private/tmp/shell_datapack.json \
  --candidate-output /private/tmp/tfl_map_candidate.json

python3 -m csr_writer tfl-shell-freeze \
  --report /private/tmp/shell_proposal.json \
  --candidate /private/tmp/tfl_map_candidate.json \
  --batch-confirmation /private/tmp/batch_confirmation.json \
  --output /private/tmp/tfl_map_frozen.json \
  --proof-output /private/tmp/freeze_proof.json

python3 -m csr_writer tfl-result-apply-rtf \
  --shell-datapack /private/tmp/shell_datapack.json \
  --frozen-map /private/tmp/tfl_map_frozen.json \
  --entity-id T14.2.4.3.1 \
  --rtf /private/tmp/deidentified-result.rtf \
  --output /private/tmp/result_datapack.json \
  --report /private/tmp/cross_format.json
```

高置信提议自动通过；同一歧义策略按批确认。无可用行列网格的 shell 实体只登记元数据，不能因批量确认而伪造 cell key；结果 RTF 若出现未冻结结构则硬失败。

M7 起，shell 行只有在能转成可读、已审语义 ID 时才建键。任何需要
`ROW_<hash>` 或 `POSITION_BLOCK_*` 才能区分的行都延后到结果 TFL；混合表仅冻结
N/Mean/SD/CI 等稳定统计行。延后合同记录占位行数、冻结列和预期术语来源；
结果阶段的 SOC/PT、ATC/药物名等按父级路径物化，同父级重名阻断，跨父级同名合法。

## M3/M5：事实、路由、深度抽取和隔离起草

### 冻结事实卡与模块路由

```bash
python3 -m csr_writer facts-card \
  --study-facts examples/demo_protocol_facts.json \
  --output examples/demo_study_facts_card.md

python3 -m csr_writer route-modules \
  --study-facts examples/demo_protocol_facts.json \
  --output /private/tmp/module-route.json
```

冻结 schema 位于 `skills/csr-writer/references/study-facts.schema.json`，只接受 `objectives / design / population / data_domains / analyses` 五维事实和明确元数据；未知字段硬失败。它显式表达 `design.study_type`、给药途径、随机/盲法/对照、临床药理专项、特殊人群、AE 后果分层和治疗领域端点。分析集 ID 不预设枚举或强制全大写，但仍要求可审计的安全字符结构。`modules.yaml` 固化 41 个模块条件。`phase` 仅生成非结构警告，不进入 capability 或结构物化。

新增 18 个模块为：

- 给药途径/局部安全：`M-LOCAL-TOLERANCE`、`M-AE-CONSEQUENCE`、`M-TOPICAL-PK`、`M-INHALATION`、`M-OPHTHALMIC`。
- 设计与对照：`M-RANDOMIZED`、`M-BLINDING`、`M-PLACEBO-CTRL`、`M-ACTIVE-CTRL`。
- 临床药理/特殊人群：`M-BE`、`M-DDI`、`M-FOOD-EFFECT`、`M-HEPATIC-IMPAIR`、`M-RENAL-IMPAIR`、`M-PEDIATRIC`、`M-GERIATRIC`。
- 领域端点示例：`M-INFECTION`、`M-DERMATOLOGY`。`oncology_response` 和 `cardiovascular_events` 只是 schema 扩展槽，尚未实现对应模块。

除 `M-BE` 外，每个新模块都有激活谓词、E3 落位、playbook、预期 TFL 类别和所需分析集；`M-BE` 按本轮边界只留激活条件，不生成结构或内容。这些是路由/内容合同，不代表新增写手已实现。完整清单见 `examples/output/m4_module_inventory.md`。脱敏外用 Ib 等价结构由原 23 模块交集中的 5 个激活模块增至 13 个；局部耐受性作为 14.3.1.3.x AE 子集输入 12.2，TEAE/TRAE 的减量/暂停/永久停药六张成对表由 `M-AE-CONSEQUENCE` 承接，皮肤科 ANCOVA 落在 11.4.2.1。

### DOCX 深度抽取

```bash
python3 -m csr_writer extract-docx \
  --docx tests/fixtures/m3-docx/deep-extraction-fixture.docx \
  --output /private/tmp/docx-extraction.json
```

抽取器只读 OOXML：正文按物理块顺序遍历，表格按行/单元格递归，文本框跟随锚点，页眉页脚按首次引用顺序追加。`w:ins` 纳入、`w:del` 排除；批注正文从不进入事实文本；直接或样式继承的 `w:vanish` 排除并仅记录位置与哈希。输入前后 SHA-256 不一致会硬失败。不调用 LibreOffice 或 PDF。

### 隔离起草

```bash
python3 -m csr_writer draft-section \
  --request examples/section_inputs/efficacy_request.json \
  --output-dir .

python3 -m csr_writer draft-section \
  --request examples/section_inputs/dose_escalation_request.json \
  --output-dir .
```

Agent 平台推荐使用两段式接口，不调用外部模型 API：

```bash
python3 -m csr_writer draft-section \
  --request examples/fixtures/m7_agent_efficacy_request.deidentified.json \
  --emit-envelope /private/tmp/11.4-envelope.json

# Agent 读取 envelope 并按严格 JSON 段落合同写入 /private/tmp/11.4-draft.json
python3 -m csr_writer draft-section \
  --envelope /private/tmp/11.4-envelope.json \
  --ingest-draft /private/tmp/11.4-draft.json \
  --output-dir /private/tmp/agent-project \
  --guard-report /private/tmp/11.4-ingest-guard.json
```

envelope 自包含当前节 playbook、绑定的语义键与最小表片段、相关来源片段，并明示其全部是数据而非指令。被守卫拒绝时，下一次 ingest 用可重复的 `--prior-guard-report` 引用前次拒绝证据；报告以 SHA-256 串联。

写手只接收当前节 playbook、审核后的语义键和相关源片段；完整 datapack、完整 study facts、其他章节或 `global_context` 均不进入上下文。系统提示明确把源文件当数据而非指令。任何裸数字、中文约数、未绑定占位符都会在发布草稿前被拒绝；§12.6 缺 DLT 键时不会用 PK 数据补位。

M3 验收后的三项修复已进入同一发布门槛：

- `semantic_guard.py` 检查因果判定、最终获益-风险结论、SAE 叙述医学内容和对缺失资料的推断。命中后强制 `needs_human=true`、`confidence=inferred`，插入 `[待医学负责人确认]`，并把 findings 写入段落及顶层 metadata。§11.4.7/§12.7/§13 及其子节默认整段待审。
- `t1/2`、`AUC0-∞`、`AUC0-t` 等 PK 参数名在数值 token 化前做等长掩码；它们不进数值白名单，同句中的真实结果值仍会被拦截。
- 分析集 schema 接受 `mFAS/mITT/mPPS`、`SS/PKS/PKCS/PKPS/BES` 和英文全称，不以静态枚举或全大写假设拒绝真实命名。

当前提供确定性隔离 adapter，以及只接受严格 JSON 的 `PromptedModelSectionAdapter`；仓库不包含外部模型端点或凭据。提示词把 playbook、TFL 绑定和来源片段全部放在用户消息的 `data` 区，不拼入系统指令。模型输出若被数值/占位符守卫拒绝，可把失败原因回喂并最多重试限定次数；语义红线继续执行“强制标记”而不是静默放行或伪装成模型错误。M6 在同一门槛下接入 §9.4.3、§9.4.6、§10.1、§11.2、§11.4、历史§11.A/§11.B、§12.1、§12.2/§12.5 及路由示例；M9 后的新产物仅使用正式数字编号。无审核来源时使用 `source_gap`，明确留空并保留人工门禁。
样例请求及产物的 `evidence_status` 为 `demo_only`，正文和元数据都标明
“合成验收夹具；非临床证据”，不得当作真实研究结果。

## M4：一致性、反向溯源和受控输出

### 组别语义校验

```bash
python3 -m csr_writer m4-group-semantics \
  --datapack examples/m4/synthetic_datapack.json \
  --section-metadata examples/m4/section_metadata.json \
  --contract examples/m4/group_contract.json \
  --output /private/tmp/m4_group_semantics.json
```

组别合同 v2 可表达任意数量组别；每组显式绑定 datapack 列，并用 10.1 随机化例数、10.3 分析集例数作两类独立锚点（仅为历史证据重放兼容 11.1）。脱敏五组结构（安慰剂、三个 BID 浓度、一个 QD 浓度）正常通过；任意两组结果列互换会以 `E-GROUP-ROLE-COLUMN` 阻断。旧 experimental/control v1 合同仍兼容。

### 反向溯源

```bash
python3 -m csr_writer m4-unreferenced-tfl \
  --datapack examples/m4/synthetic_datapack.json \
  --section-metadata examples/m4/section_metadata.json \
  --output /private/tmp/unreferenced_tfl.md \
  --report /private/tmp/unreferenced_tfl.json
```

程序遍历 datapack 全部有结果实体与各节 `binding_manifest`；未引用表进入人工复核清单，引用不存在的表/单元格则硬失败。`metadata_only` 图/清单参加表级登记，但不会被误报为“有结果未引用”。另有四层 trace-chain 合同逐条证明方案→SAP→TFL→CSR，并分别从 CSR 和 TFL 反向走回方案；缺任一审核边即硬失败。

### 跨章与 Synopsis

`m4-cross-check` 只检查受控合同：对比 9.7/10.1/11/12 的分析集定义，检查正文/13 章/Synopsis 的 claim stance 与 evidence keys，并核验 Synopsis 是已确认正文段落的逐字派生副本。Synopsis 不存在独立写手，manifest 记录源节、源段落和哈希。这是限定合同检查，不是不受限的医学一致性审阅。

### annotated / clean 双输出

`m4-assemble` 始终可生成带高亮待确认标记与段落溯源的 annotated DOCX。clean 与 Synopsis DOCX 只在每个待审段落都有与当前 `draft_sha256` 绑定的显式人工处置后生成。两者先在暂存 OOXML 包上扫描，拒绝任何待确认/待核实/待补充标记、未解析占位符、内部错误码、内部溯源、工具名和过程/QC 语言，通过后才原子发布。

### QC 结论权限

`m4-qc-report` 仅汇总已执行检查。无 finding 时只能表述“未发现本次已执行检查所覆盖的 XX 类问题”。`申报就绪`、`可以递交`、`符合 CDE 要求` 等结论会被权限护栏拒绝。

M4 CLI 的完整参数可用 `python3 -m csr_writer <command> --help` 查看；可运行的合同示例在 `examples/m4/`，组装中的人工决定必须与当次草稿哈希绑定，不提供可盲目复用的“自动同意”文件。

## M5：真实 shell、Codex 入口与发布边界

真实 shell 验收按外部文件批准 SHA-256 定位，不把文件名或路径写入产物。实测结果见 `examples/output/m5/M5真实Shell端到端报告.md`：正文 175 个物理表对象、全故事 179 个对象/7424 个单元格；175/175 对象均有提议。110 个唯一 TFL 实体中 30 个高置信自动通过，其余 80 个合并为 3 个批量确认动作。对象提议覆盖率 100% 不等于语义准确率；高置信实体率为 27.27%，报告明确保留这一区分。

跨格式演示从真实 DOCX shell 冻结结构，为 D1/D28 两个实体生成只含 ASCII 语义 ID 和合成值的 RTF，再套入 3344-cell datapack。行 ID、列 ID、物理坐标或语义键任一漂移都会阻断。外用 PK 样例在该结构上完成写手、resolve、A/B/C 守卫、annotated/clean/Synopsis、双向及反向溯源；真实 shell 对 §11.4/§11.A 不足以形成完整已审绑定时按 `source_gap` 处理，没有猜测补齐。

Codex 入口为根目录 `AGENTS.md`。`.claude-plugin/plugin.json` 暂保留为兼容性元数据，不承载逻辑。`test_codex_platform_boundary.py` 会复制运行时、删除 `AGENTS.md`、`.claude-plugin/`、`SKILL.md` 和 `agents/`，再跑完整 unittest 和所有 CLI 子命令的 `--help`，防止逻辑回流到平台专有文档。

## M6：版式继承、追溯分流和完整批注骨架

版式引用规则位于 `skills/csr-writer/references/layout-reference-patterns.json`。提议器只对原本因“无可用行列网格”进入队列的单实体应用规则，并先建立引用图：循环、目标不存在、目标本身仍为引用或目标无独立网格都会硬失败。治疗列可以继承；统计量行可以继承；SOC/PT 等数据驱动行只冻结列合同并标记 `columns_only_deferred_rows`，等待结果 TFL 展开。引用来源、模式、列合同与行分类器均进入候选和冻结哈希。

同一真实 shell 的 M6 实测为 83/110 个高置信实体，27 个进入 2 个批量动作；53 个实体通过版式继承获网格，其中 38 个仅继承列并延后数据驱动行，15 个继承完整统计网格。反向溯源把未引用表按 §10.1、§11.2、§11.4、§11.B、§12.1、§12.2 等预期章节分组，只有无法归类项进入立即人工队列。

`project_skeleton.py` 在已验证 M1 标题树上装配路由贡献、受控分节内容、Word REF 域、段落溯源和显式 source gap。真实 shell 不含临床结果，因此完整 annotated 骨架不会把 `xx` 当结果；§2 Synopsis 在正文确认前保持锁定。实际证据和自主设计边界见 `M6交付说明.md`。

## M7：占位行正确性与 Agent 写手

同一真实 shell 的保守重跑结果为：`cell_level` 从 52 个降至 28 个，冻结候选键从 5388 个降至 2848 个，位置/不透明行键从 3822 个降至 0 个。高置信实体从 83/110 回落至 47/110（42.73%），63 个实体进入 3 个批量人工队列；这是消除静默错值风险的预期结果，不将自动率回落粉饰成性能提升。

脱敏异构 RTF 回归已覆盖 5 个 SOC、每类 2–7 个 PT、跨 SOC 同名 PT、ATC/药物名、稳定 ANCOVA 行以及硬失败漂移。Agent 实测完成 §11.4 与 §12.2；首轮各有 1 段因人工确认标记形式不精确而被拦，各重试 1 次后通过。两节均通过 resolve 三道守卫并装配 annotated DOCX；待审段落未关闭，clean 版没有生成。详见 `M7交付说明.md`。

## M8：按审阅判断组织的人工队列

```bash
python3 -m csr_writer tfl-review-queue \
  --report examples/output/m8/real_shell_proposal_report.json \
  --candidate examples/output/m8/tfl_map_candidate.deidentified.json \
  --output /private/tmp/review_queue.json \
  --markdown-output /private/tmp/review_queue.md \
  --deferred-rows-output /private/tmp/deferred_rows.md
```

真实 shell 的 3 个技术批次、63 个实体被拆成 15 个真实判断组。分类包括编码字典依赖、分析集平行表、同族策略、版式继承范围、延后行来源和结构异常；54 个实体同时需要两类以上判断。Markdown 展示每组共同判断点、1–2 个完整代表结构、其余成员的差异、默认决定、推翻后果和下游键/章节影响。

`tfl-review-decide` 生成单项可归责记录；`tfl-review-ledger` 要求每组恰好一条当前记录；`tfl-review-freeze` 只接受完整且无 defer 的 ledger。记录同时绑定提议报告、队列、决策组和自身 SHA-256。`tfl-review-compare` 用 own/dependency/effective 三层结构哈希区分“未变沿用”“自身变化重新入队”“继承源变化导致失效重确认”，并输出字段级差异。

`tfl-review-template-export` 不导出审阅者身份；`tfl-review-template-apply` 只生成带 `requires_human_confirmation` 的建议，自动决定数固定为 0。全部命令均只读输入并原子写出结构化 JSON/Markdown。

## M9：事实路由的项目结构裁剪

`render-project-skeleton` 同时产出 annotated/clean 结构版和删节留痕。默认物理删除条件不满足的节；只有显式传入 `--omission-policy retain_not_applicable` 才保留标题和事实派生理由。

```bash
python3 -m csr_writer render-project-skeleton \
  --study-facts examples/fixtures/paired_topical_project_facts.deidentified.json \
  --content-manifest examples/output/m9/content_manifest.deidentified.json \
  --publication-reference-map examples/fixtures/m9_publication_reference_map.deidentified.json \
  --annotated-output /private/tmp/csr-m9-annotated.docx \
  --clean-output /private/tmp/csr-m9-clean.docx \
  --annotated-scaffold /private/tmp/csr-m9-annotated-scaffold.docx \
  --clean-scaffold /private/tmp/csr-m9-clean-scaffold.docx \
  --report /private/tmp/csr-m9-report.json \
  --omitted-sections /private/tmp/csr-m9-omitted.md
```

新骨架不再产生 11.A/11.B。源 TFL 语义 ID 不作发表号；只有已确认的发表映射才可创建如 `T14.3-4` 的书签和 REF 域。完整脱敏证据包位于 `examples/output/m9/`，内含外用研究两版 DOCX 和肿瘤剂量递增对照 DOCX。

## M10：结构纠正与方案事实反向核对

官方 `ICH-E3章节树.yaml` 保持逐字核验状态；本地化标题放在
`skills/csr-writer/references/title-overrides.yaml`，每条必须同时记录官方中英文、
本地化标题和理由。`source-file-lock.json` 锁定四份规格源及仓库内骨架副本，完整
unittest 会逐字节复核。

项目骨架保留 E3 编号断层，并在受影响章首输出人类可读的不适用声明；内部
`omitted_sections.md` 继续记录事实字段。缺少具体方案事实时禁止仅因“没有支持模块”
自动删除，当前 11.4.3/11.4.6 会保留并进入人工队列。16.x 永不删除，16.0 的
五列表格覆盖全部官方附录项并区分随 CSR、地区性、TMF 备索和不适用。

方案反向核对命令只提出问题，不修改 facts：

```bash
python3 -m csr_writer scan-protocol-facts \
  --docx "<只读方案.docx>" \
  --expected-sha256 "<批准哈希>" \
  --study-facts examples/fixtures/paired_topical_project_facts.deidentified.json \
  --report /private/tmp/protocol-fact-scan.json \
  --markdown-output /private/tmp/protocol-fact-scan.md
```

规则位于 `protocol-facts-scan-rules.yaml`。报告给出方案节、脱敏引文、当前字段值和
人工核对问题；否定性表述、背景文献和一般稽查条款也可能命中，这是“宁可多报”
边界的预期行为。完整 M10 脱敏证据位于 `examples/output/m10/`。

## M11：结构收口、写作分层与试水

项目骨架现在把附录清单和删节说明作为正式正文渲染：16.0 与第 3 章附录目录均
使用同一份 24 条、五列、四分类数据源；删节理由作为普通正文段落出现，clean 与
annotated 均保留。第 12 章将剂量递增固定为 12.6，安全性结论固定为 12.7，渲染前
同时检查编号单调性和结论同级末位。

分析集由 `analyses.analysis_sets` 动态生成在 10.3，组别语义校验以 10.3 为当前
分析集锚点并兼容历史 11.1 证据重放。终点方法按主要、关键次要、其他次要、探索性、
安全性、局部耐受性及 PD/生物标志物/PRO 展开；结果章按相同层级或其领域专项节响应。
所有可选安全性小节均由显式 facts 激活；免疫原性按安全性专项定位于 12.5.6。

写作分层命令会列出每个可见标题、叶级起草单元、已有 playbook、预计行数和 AI
省力比例：

```bash
python3 -m csr_writer authoring-inventory \
  --study-facts examples/fixtures/paired_topical_project_facts.deidentified.json \
  --output /private/tmp/authoring-inventory.json \
  --markdown-output /private/tmp/authoring-inventory.md
```

当前脱敏项目为 150 个可见标题、120 个叶级起草单元，其中 35 个需要完整结果类
playbook。四节 Agent 试水保留 envelope、原始段落、首次拒绝、重试、resolve 守卫、
可读 Markdown 与 annotated DOCX；没有调用外部模型 API，也没有人工润色正文。
完整证据位于 `examples/output/m11/`。

## 示例交付物

- `examples/output/CSR_ICH_E3_骨架示例.docx`
- `examples/output/skeleton_manifest.json`
- `examples/output/qc_format_report.json` / `.txt`
- `examples/output/poc4_qc_report.txt`
- `examples/output/docx_schema_validation.txt`
- `examples/output/parsed_tables.json`
- `examples/output/datapack.json`
- `examples/output/resolved.txt`
- `examples/output/guard_report.json`
- `examples/demo_protocol_facts.json` / `demo_study_facts_card.md`
- `examples/output/m3_numeric_guard_regression.json`
- `examples/output/m3_module_coverage.md` / `m3_routing_acceptance.json`
- `tests/fixtures/m3-docx/deep-extraction-fixture.docx`
- `examples/output/m3_docx_extraction.json` / `m3_docx_fixture_validation.txt`
- `sections/11.4.md` / `11.4.meta.json`
- `sections/11.A.md` / `11.A.meta.json`
- `sections/resolved/` 下两节 resolve 成品与守卫报告
- `examples/output/m3_e2e_summary.json`
- `examples/output/m3_final_validation.md`
- `examples/output/m4_module_inventory.md`
- `examples/output/m4_module_expansion_acceptance.json`
- `examples/output/m4_topical_module_comparison.md`
- `examples/output/m4/group_semantics_pass.json`
- `examples/output/m4/group_semantics_swap_blocked.json`
- `examples/output/m4/group_trace_acceptance.json`
- `examples/output/m4/unreferenced_tfl.md` / `.json`
- `examples/output/real_material_driven/README.md` 与同目录全部 JSON 证据
- `examples/output/m5/M5真实Shell端到端报告.md` / `m5_e2e_summary.json`
- `examples/output/m5/real_shell_proposal_report.json` / `tfl_map_frozen.demo.json`
- `examples/output/m5/cross_format_apply.json` / `cross_format_drift_blocked.json`
- `examples/output/m5/writer_section_inventory.json` 与 `writer_samples/`
- `examples/output/m5/real_pipeline/` 下 annotated/clean/Synopsis 与分节证据
- `examples/output/m5/unreferenced_tfl.md` / `qc_report.md` / `source_hash_audit.json`
- `examples/output/m9/CSR_DEID_M9_pruned_skeleton_annotated.docx`
- `examples/output/m9/CSR_DEID_M9_pruned_skeleton_clean.docx`
- `examples/output/m9/CSR_DEID_M9_oncology_escalation_skeleton_clean.docx`
- `examples/output/m9/M9结构裁剪与修正端到端报告.md`
- `examples/output/m9/structure_pruning_comparison.json` / `omitted_sections.md`
- `examples/output/m9/not_applicable_mode_proof.json`
- `examples/output/m9/formal_heading_and_toc_proof.json`
- `examples/output/m9/section_12_merge_and_local_tolerance_proof.json`
- `examples/output/m9/chapter14_reference_consistency.json` / `appendix_status_plan.json`
- `examples/output/m9/ooxml_qc_annotated.json` / `ooxml_qc_clean.json`
- `examples/output/m9/source_hash_audit.json` / `privacy_scan.json`
- `examples/output/m9/oncology_clean_skeleton_report.json`
- `examples/output/m10/CSR_DEID_M10_skeleton_annotated.docx`
- `examples/output/m10/CSR_DEID_M10_skeleton_clean.docx`
- `examples/output/m10/M10端到端报告.md` / `m10_e2e_summary.json`
- `examples/output/m10/structure_correction_proof.json` / `appendix_status_plan.json`
- `examples/output/m10/protocol_fact_scan_paired.md` / `protocol_fact_scan_reference.md`
- `examples/output/m10/protocol_fact_scan_assessment.json`
- `examples/output/m10/source_integrity_proof.json` / `title_override_proof.json`
- `examples/output/m10/ooxml_qc_annotated.json` / `ooxml_qc_clean.json`
- `examples/output/m11/CSR_DEID_M11_skeleton_annotated.docx`
- `examples/output/m11/CSR_DEID_M11_skeleton_clean.docx`
- `examples/output/m11/16.0附录状态清单.md` / `omitted_sections.md`
- `examples/output/m11/章节写作分层清单.md` / `authoring_inventory.json`
- `examples/output/m11/structure_strengthening_proof.json`
- `examples/output/m11/writing_trial/起草样例.md`
- `examples/output/m11/writing_trial/M11_writing_trial_annotated.docx`
- `examples/output/m11/writing_trial/writing_trial_summary.json`
- `examples/output/m11/source_hash_audit.json` / `privacy_scan.json`
- `examples/output/m5/platform_boundary_test.json`
- `examples/output/m6/M6真实项目可用性端到端报告.md` / `m6_e2e_summary.json`
- `examples/output/m6/CSR_DEID_complete_skeleton_annotated.docx`
- `examples/output/m6/m5_m6_real_shell_comparison.json` / `layout_inheritance_proof.json`
- `examples/output/m6/unreferenced_tfl.md` / `章节覆盖清单.md`
- `examples/output/m6/model_interface_and_guard_retry_proof.json`
- `examples/output/m6/source_hash_audit.json` / `privacy_scan.json`
- `examples/output/m7/M7正确性与Agent写手端到端报告.md` / `m7_e2e_summary.json`
- `examples/output/m7/m6_m7_placeholder_row_comparison.json`
- `examples/output/m7/heteromorphic_results/heteromorphic_result_proof.json`
- `examples/output/m7/agent_writer/agent_writer_and_assembly_proof.json`
- `examples/output/m7/agent_writer/assembly/agent_drafted_sections_annotated.docx`
- `examples/output/m7/source_hash_audit.json` / `privacy_scan.json`
- `examples/output/m8/review_decision_queue.md` / `.json`
- `examples/output/m8/review_ergonomics.json`
- `examples/output/m8/decision_record.example.json` / `decision_ledger.demo.json`
- `examples/output/m8/deferred_row_expectations.representatives.md`
- `examples/output/m8/version_reuse/shell_v1.0.deidentified.docx` / `shell_v1.1.deidentified.docx`
- `examples/output/m8/version_reuse/version_reuse_proof.md` / `.json`
- `examples/output/m8/decision_template.demo.json` / `template_application_proof.json`
- `examples/output/m8/source_hash_audit.json` / `privacy_scan.json`

M5 历史说明见 `DELIVERY.md`；M6–M10 的设计决定分别见对应的 `M6交付说明.md` 至
`M10交付说明.md`，M11 设计决定见 `examples/output/m11/交付说明.md`。真实文件始终在
外部原位只读，数值与正文样例均为脱敏或资料缺口内容。
