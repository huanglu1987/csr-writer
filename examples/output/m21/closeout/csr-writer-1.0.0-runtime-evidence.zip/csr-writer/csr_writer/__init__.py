"""Controlled CSR authoring workflow implemented through milestone M21."""

__version__ = "1.0.0"
