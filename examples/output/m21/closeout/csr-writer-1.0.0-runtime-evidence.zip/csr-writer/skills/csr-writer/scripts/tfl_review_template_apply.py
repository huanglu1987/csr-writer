#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from csr_writer.cli import main


if __name__ == "__main__":
    raise SystemExit(main(["tfl-review-template-apply", *__import__("sys").argv[1:]]))
